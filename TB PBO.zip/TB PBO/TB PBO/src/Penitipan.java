//interface
public interface Penitipan {
    public void noPenitipan();
    public void namaPemilik();
    public void noHP();
    public void namaKucing();
    public void ras();
    public void jenisKandang();
    public void biayaPenitipan();
    public void lamaPenitipan();
    public void totalBiaya();
}